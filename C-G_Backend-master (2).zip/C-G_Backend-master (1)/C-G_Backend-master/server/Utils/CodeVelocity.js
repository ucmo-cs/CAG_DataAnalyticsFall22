const fs = require('fs');
const jsonwebtoken = require('jsonwebtoken'); // $ npm install jsonwebtoken
const axios = require('axios');
const keyUtils = require('./keyUtils.js');
const request = require('request');
const { Console } = require('console');

var methods = {
    CodeVelcoity:function(data) {
        var numofcards =  data.pagination.total;
        var time_completed = 0;
        var avgsprinttime = data.pagnation.created_at - data.pagnation.closed_at;
        for(i=0;i < numofcards; i++){
            if(category_name = "Ready"){
                time_completed++;
                console.log(data.data(i.sprint.title));
                console.log(data.data(i.sprint.avgsprinttime));
            }


        }

    }
};
exports.functions = methods;