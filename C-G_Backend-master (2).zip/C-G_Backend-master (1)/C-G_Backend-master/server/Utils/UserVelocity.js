const fs = require('fs');
const jsonwebtoken = require('jsonwebtoken'); // $ npm install jsonwebtoken
const axios = require('axios');
const keyUtils = require('./keyUtils.js');
const request = require('request');
const { Console } = require('console');

var methods = {
    UserVelocity:function(data) {
        var numofcard = data.pagination.total;
        var avgsprinttime= (data.data.created_at)-(data.data.updated_at)/ numofcards;
        for(i=0;i < numofcard;i++){
            if(category_name = "Ready"){
                console.log(data.data(i.creator.name));
                console.log(data.data(i.data.points));
                console.log(i.data.avgsprinttime);
            }
        }
    
}
};
exports.functions = methods;