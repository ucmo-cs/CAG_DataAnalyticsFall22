const fs = require('fs');
const jsonwebtoken = require('jsonwebtoken'); // $ npm install jsonwebtoken
const axios = require('axios');
const keyUtils = require('./keyUtils.js');
const request = require('request');
const { Console } = require('console');

var methods = {
    Aging:function(data){
        var numofcards = data.pagination.total
        for(i=0;i < numofcard; i++){
            if(state == "open" && closer_id == null){
                console.log(data.data(i.creator_id));
                console.log(data.data(i.updated_at));
            }
                
            }
            
             
    }
};exports.function = methods;