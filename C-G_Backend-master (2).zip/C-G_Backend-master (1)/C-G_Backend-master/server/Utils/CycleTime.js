const fs = require('fs');
const jsonwebtoken = require('jsonwebtoken'); // $ npm install jsonwebtoken
const axios = require('axios');
const keyUtils = require('./keyUtils.js');
const request = require('request');
const { Console } = require('console');

var methods = {
    CycleTime:function(data){
        var cycletime = 0;
        if(category_name = "done"){
            cycletime = data.closed_at-data.created_at;
            console.log(cycletime);
        }
    }
};
exports.functions = methods;
