const fs = require('fs');
const jsonwebtoken = require('jsonwebtoken'); // $ npm install jsonwebtoken
const axios = require('axios');
const keyUtils = require('./keyUtils.js');
const request = require('request');
const { Console } = require('console');
// const cors = require('cors');


var methods = {
    example:function(data) {
        
        var numofcards = data.pagination.total
        for(i=0;i<numofcards;i++){
            console.log(data.data(i.creator.name));

        }
    }
    
   

};
exports.functions = methods;
